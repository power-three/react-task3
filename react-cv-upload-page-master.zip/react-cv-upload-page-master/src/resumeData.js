let resumeData = {
    "socialLinks":[
        {
          "name":"github",
          "url":"https://github.com/power-three",
          "className":"fa fa-github"
        }
      ],
  } 
  export default resumeData