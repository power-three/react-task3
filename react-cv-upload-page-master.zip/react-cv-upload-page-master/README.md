# react-cv-upload-page

#How to start
- clone or download project
- download this file https://drive.google.com/file/d/1lx4gFDrnH1p77Ssmo81cafC2fAeia1Ne/view?usp=sharing
- install npm and node.js and react
- in terminal go to project director 
- run this command > npm start
